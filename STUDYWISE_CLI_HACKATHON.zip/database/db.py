import sqlite3
from pathlib import Path
from contextlib import closing

BASE_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = BASE_DIR / "data"
DB_PATH = DATA_DIR / "studywise.db"
SCHEMA_VERSION = 1


def get_connection():
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    conn.execute("PRAGMA journal_mode = WAL")
    conn.execute("PRAGMA synchronous = NORMAL")
    return conn


def execute(sql, params=()):
    with closing(get_connection()) as conn:
        cur = conn.execute(sql, params)
        conn.commit()
        return cur.lastrowid


def executemany(sql, params_list):
    with closing(get_connection()) as conn:
        conn.executemany(sql, params_list)
        conn.commit()


def query_all(sql, params=()):
    with closing(get_connection()) as conn:
        return conn.execute(sql, params).fetchall()


def query_one(sql, params=()):
    with closing(get_connection()) as conn:
        return conn.execute(sql, params).fetchone()


def init_db():
    with closing(get_connection()) as conn:
        conn.executescript("""
        CREATE TABLE IF NOT EXISTS app_meta (
            key TEXT PRIMARY KEY,
            value TEXT NOT NULL
        );

        CREATE TABLE IF NOT EXISTS profile (
            id INTEGER PRIMARY KEY CHECK(id=1),
            name TEXT NOT NULL DEFAULT 'User',
            xp INTEGER NOT NULL DEFAULT 0,
            streak INTEGER NOT NULL DEFAULT 0,
            last_active TEXT
        );

        CREATE TABLE IF NOT EXISTS subjects (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL UNIQUE,
            created_at TEXT NOT NULL
        );

        CREATE TABLE IF NOT EXISTS study_tasks (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            subject_id INTEGER NOT NULL,
            title TEXT NOT NULL,
            task_date TEXT NOT NULL,
            duration INTEGER NOT NULL CHECK(duration > 0),
            status TEXT NOT NULL DEFAULT 'pending' CHECK(status IN ('pending','completed')),
            created_at TEXT NOT NULL,
            FOREIGN KEY(subject_id) REFERENCES subjects(id) ON DELETE CASCADE
        );

        CREATE TABLE IF NOT EXISTS study_sessions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            subject_id INTEGER,
            task_id INTEGER,
            minutes INTEGER NOT NULL CHECK(minutes > 0),
            session_date TEXT NOT NULL,
            FOREIGN KEY(subject_id) REFERENCES subjects(id) ON DELETE SET NULL,
            FOREIGN KEY(task_id) REFERENCES study_tasks(id) ON DELETE SET NULL
        );

        CREATE TABLE IF NOT EXISTS expenses (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            amount REAL NOT NULL CHECK(amount > 0),
            category TEXT NOT NULL,
            description TEXT,
            expense_date TEXT NOT NULL
        );

        CREATE TABLE IF NOT EXISTS budgets (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            month TEXT NOT NULL UNIQUE,
            amount REAL NOT NULL CHECK(amount >= 0)
        );

        CREATE TABLE IF NOT EXISTS decks (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL UNIQUE,
            subject TEXT
        );

        CREATE TABLE IF NOT EXISTS flashcards (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            deck_id INTEGER NOT NULL,
            question TEXT NOT NULL,
            answer TEXT NOT NULL,
            interval INTEGER NOT NULL DEFAULT 1,
            ease REAL NOT NULL DEFAULT 2.5,
            repetitions INTEGER NOT NULL DEFAULT 0,
            next_review TEXT NOT NULL,
            FOREIGN KEY(deck_id) REFERENCES decks(id) ON DELETE CASCADE
        );

        CREATE TABLE IF NOT EXISTS reviews (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            card_id INTEGER NOT NULL,
            quality INTEGER NOT NULL CHECK(quality BETWEEN 1 AND 5),
            reviewed_at TEXT NOT NULL,
            FOREIGN KEY(card_id) REFERENCES flashcards(id) ON DELETE CASCADE
        );

        CREATE INDEX IF NOT EXISTS idx_tasks_date ON study_tasks(task_date);
        CREATE INDEX IF NOT EXISTS idx_sessions_date ON study_sessions(session_date);
        CREATE INDEX IF NOT EXISTS idx_expenses_date ON expenses(expense_date);
        CREATE INDEX IF NOT EXISTS idx_cards_review ON flashcards(next_review);
        CREATE INDEX IF NOT EXISTS idx_reviews_date ON reviews(reviewed_at);

        INSERT OR IGNORE INTO profile(id, name) VALUES(1, 'User');
        INSERT OR REPLACE INTO app_meta(key, value) VALUES('schema_version', '1');
        """)
        conn.commit()


def backup_db(destination=None):
    """Create a consistent SQLite backup and return its path."""
    import shutil
    from datetime import datetime
    destination = Path(destination) if destination else DATA_DIR / f"studywise_backup_{datetime.now():%Y%m%d_%H%M%S}.db"
    destination.parent.mkdir(parents=True, exist_ok=True)
    with closing(get_connection()) as source, sqlite3.connect(destination) as target:
        source.backup(target)
    return destination
