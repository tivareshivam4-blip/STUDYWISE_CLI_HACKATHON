from datetime import date
from rich.console import Group
from rich.table import Table
from rich.panel import Panel
from rich.columns import Columns
from database.db import query_one, query_all
from modules.gamification import get_level
from ui import console, title, stat_card, progress_panel, APP_CYAN, APP_GREEN, APP_YELLOW, APP_MAGENTA, DIM


def metrics():
    today = date.today().isoformat()
    month = today[:7]
    study_today = query_one("SELECT COALESCE(SUM(minutes),0) total FROM study_sessions WHERE session_date=?", (today,))["total"]
    pending = query_one("SELECT COUNT(*) c FROM study_tasks WHERE task_date=? AND status='pending'", (today,))["c"]
    completed = query_one("SELECT COUNT(*) c FROM study_tasks WHERE task_date=? AND status='completed'", (today,))["c"]
    total_today = query_one("SELECT COUNT(*) c FROM study_tasks WHERE task_date=?", (today,))["c"]
    cards_due = query_one("SELECT COUNT(*) c FROM flashcards WHERE next_review<=?", (today,))["c"]
    total_cards = query_one("SELECT COUNT(*) c FROM flashcards")["c"]
    spent = query_one("SELECT COALESCE(SUM(amount),0) total FROM expenses WHERE substr(expense_date,1,7)=?", (month,))["total"]
    budget_row = query_one("SELECT amount FROM budgets WHERE month=?", (month,))
    budget = budget_row["amount"] if budget_row else 0
    profile = query_one("SELECT xp,streak,name FROM profile WHERE id=1")
    level, current, needed = get_level(profile["xp"])
    return locals()


def productivity_score(m):
    task_score = 100 if m["total_today"] and m["completed"] >= m["total_today"] else (m["completed"] / max(1, m["total_today"]) * 100)
    study_score = min(100, m["study_today"] / 120 * 100)
    revision_score = 100 if m["total_cards"] and m["cards_due"] == 0 else (60 if m["total_cards"] else 50)
    budget_score = 100 if not m["budget"] else max(0, min(100, 100 - (m["spent"] / m["budget"] * 100)))
    return round(study_score*.4 + revision_score*.3 + budget_score*.2 + task_score*.1)


def show_dashboard(compact=False):
    m = metrics()
    score = productivity_score(m)
    if compact:
        console.print(Panel(
            f"[bold]📚 {m['study_today']} min[/bold]  •  [bold]💰 ₹{m['spent']:.0f}[/bold]  •  "
            f"[bold]🧠 {m['cards_due']} due[/bold]  •  [bold]🔥 {m['profile']['streak']} day streak[/bold]  •  "
            f"[bold]🎯 {score}/100[/bold]",
            border_style=APP_CYAN, padding=(0, 1)))
        return

    title("⚡ STUDYWISE", "PERSONAL PRODUCTIVITY COMMAND CENTER")
    console.print(Columns([
        stat_card("STUDY TODAY", f"{m['study_today']} min", f"{m['pending']} tasks pending", APP_CYAN),
        stat_card("MONTH SPEND", f"₹{m['spent']:.0f}", f"Budget ₹{m['budget']:.0f}" if m['budget'] else "Budget not set", APP_GREEN),
        stat_card("FLASHCARDS DUE", str(m['cards_due']), f"{m['total_cards']} cards total", APP_MAGENTA),
        stat_card("STREAK", f"🔥 {m['profile']['streak']}", f"Level {m['level']} • {m['profile']['xp']} XP", APP_YELLOW),
    ], equal=True, expand=True))

    console.print(progress_panel(f"Productivity Score  •  {score}/100", score, 100, APP_CYAN))
    console.print(progress_panel(f"XP to Level {m['level'] + 1}  •  {m['current']}/{m['needed']}", m['current'], m['needed'], APP_YELLOW))

    tasks = query_all("""SELECT s.name,t.title,t.duration,t.status FROM study_tasks t
                        JOIN subjects s ON s.id=t.subject_id WHERE t.task_date=?
                        ORDER BY t.status DESC,t.id LIMIT 6""", (date.today().isoformat(),))
    table = Table(title="Today's Focus", box=None, header_style="bold cyan")
    table.add_column("Status", width=8)
    table.add_column("Subject")
    table.add_column("Task")
    table.add_column("Time", justify="right")
    for r in tasks:
        status = "[green]✓ DONE[/green]" if r["status"] == "completed" else "[yellow]○ TODO[/yellow]"
        table.add_row(status, r["name"], r["title"], f"{r['duration']} min")
    if not tasks:
        table.add_row("-", "-", "No tasks scheduled for today", "-")
    console.print(Panel(table, border_style=APP_CYAN))

    bycat = query_all("""SELECT category,SUM(amount) total FROM expenses
                        WHERE substr(expense_date,1,7)=? GROUP BY category ORDER BY total DESC LIMIT 5""", (m["month"],))
    if bycat:
        et = Table(title="Top Spending Categories", box=None, header_style="bold green")
        et.add_column("Category"); et.add_column("Amount", justify="right")
        for r in bycat:
            et.add_row(r["category"], f"₹{r['total']:.2f}")
        console.print(Panel(et, border_style=APP_GREEN))


def dashboard_menu():
    show_dashboard()
