from datetime import date, timedelta, datetime
from rich.console import Console
from rich.table import Table
from rich.prompt import Prompt, IntPrompt
from rich.panel import Panel
from rich.columns import Columns
from ui import clear, title, menu, footer, stat_card, APP_MAGENTA, APP_CYAN, APP_YELLOW

from database.db import execute, query_all, query_one
from modules.gamification import add_xp

console = Console()

def create_deck():
    name = Prompt.ask("Deck name")
    subject = Prompt.ask("Subject", default="")
    try:
        execute("INSERT INTO decks(name,subject) VALUES(?,?)", (name, subject))
        console.print("[green]✓ Deck created[/green]")
    except Exception:
        console.print("[yellow]Deck already exists.[/yellow]")

def list_decks():
    rows = query_all("SELECT * FROM decks ORDER BY name")
    if not rows:
        console.print("[yellow]No decks yet.[/yellow]")
        return []
    t = Table(title="Flashcard Decks")
    t.add_column("ID"); t.add_column("Deck"); t.add_column("Subject")
    for r in rows:
        t.add_row(str(r["id"]), r["name"], r["subject"] or "-")
    console.print(t)
    return rows

def add_card():
    if not list_decks():
        return
    did = IntPrompt.ask("Deck ID")
    if not query_one("SELECT id FROM decks WHERE id=?", (did,)):
        console.print("[red]Invalid deck.[/red]")
        return
    q = Prompt.ask("Question")
    a = Prompt.ask("Answer")
    execute("""INSERT INTO flashcards(deck_id,question,answer,next_review)
               VALUES(?,?,?,?,?)""",
            (did,q,a,date.today().isoformat()))
    console.print("[green]✓ Flashcard added and due today.[/green]")

def update_sm2(card_id, quality):
    # Simplified SM-2-inspired scheduler.
    card = query_one("SELECT * FROM flashcards WHERE id=?", (card_id,))
    q = quality
    ease = max(1.3, card["ease"] + (0.1 - (5-q)*(0.08 + (5-q)*0.02)))
    if q < 3:
        repetitions = 0
        interval = 1
    else:
        repetitions = card["repetitions"] + 1
        if repetitions == 1:
            interval = 1
        elif repetitions == 2:
            interval = 3
        else:
            interval = max(1, round(card["interval"] * ease))
    next_date = date.today() + timedelta(days=interval)
    execute("""UPDATE flashcards SET interval=?,ease=?,repetitions=?,next_review=?
               WHERE id=?""",
            (interval,ease,repetitions,next_date.isoformat(),card_id))
    execute("INSERT INTO reviews(card_id,quality,reviewed_at) VALUES(?,?,?)",
            (card_id,q,datetime.now().isoformat(timespec="seconds")))
    add_xp(5)

def study_cards():
    rows = query_all("""SELECT f.*,d.name deck FROM flashcards f
                        JOIN decks d ON d.id=f.deck_id
                        WHERE f.next_review<=?
                        ORDER BY f.next_review,f.id""", (date.today().isoformat(),))
    if not rows:
        console.print("[green]🎉 No cards due today![/green]")
        return
    console.print(f"[cyan]{len(rows)} cards due.[/cyan]")
    for card in rows:
        console.print(Panel(f"[bold]{card['question']}[/bold]", title=f"🧠 {card['deck']}"))
        Prompt.ask("Press Enter to reveal", default="")
        console.print(Panel(card["answer"], title="Answer"))
        quality = IntPrompt.ask("Rate: 1=Again 2=Hard 3=Good 4=Easy 5=Perfect", default=4)
        quality = max(1, min(5, quality))
        update_sm2(card["id"], quality)
        console.print("[green]✓ Scheduled for next review. +5 XP[/green]")

def progress():
    total = query_one("SELECT COUNT(*) c FROM flashcards")["c"]
    due = query_one("SELECT COUNT(*) c FROM flashcards WHERE next_review<=?",
                    (date.today().isoformat(),))["c"]
    reviews = query_one("SELECT COUNT(*) c FROM reviews")["c"]
    console.print(Panel(f"Total cards: {total}\nDue today: {due}\nReviews completed: {reviews}",
                        title="🧠 Flashcard Progress"))

def flashcard_menu():
    while True:
        clear()
        title("🧠 FLASHCARDS", "REMEMBER MORE • REVIEW LESS", APP_MAGENTA)
        today = date.today().isoformat()
        decks = query_one("SELECT COUNT(*) c FROM decks")["c"]
        cards = query_one("SELECT COUNT(*) c FROM flashcards")["c"]
        due = query_one("SELECT COUNT(*) c FROM flashcards WHERE next_review<=?", (today,))["c"]
        console.print(Columns([
            stat_card("DECKS", str(decks), "Study collections", APP_MAGENTA),
            stat_card("TOTAL CARDS", str(cards), "Saved knowledge", APP_CYAN),
            stat_card("DUE TODAY", str(due), "Ready for review", APP_YELLOW),
        ], equal=True, expand=True))
        choices = {"1":"➕  Create Deck","2":"📝  Add Flashcard","3":"▶   Study Due Cards","4":"📚  View Decks","5":"📈  View Progress","0":"↩  Back"}
        menu(choices, APP_MAGENTA)
        footer("Choose a learning action")
        c = Prompt.ask("", choices=list(choices), default="0", show_default=False)
        if c=="1": create_deck()
        elif c=="2": add_card()
        elif c=="3": study_cards()
        elif c=="4": list_decks()
        elif c=="5": progress()
        else: break
        Prompt.ask("\nPress Enter", default="")
