from datetime import date
from rich.console import Console
from rich.table import Table
from rich.prompt import Prompt, IntPrompt, FloatPrompt
from rich.panel import Panel
from rich.columns import Columns
from ui import clear, title, menu, footer, stat_card, APP_GREEN, APP_YELLOW, APP_RED

from database.db import execute, query_all, query_one
from modules.gamification import add_xp

console = Console()

def add_expense():
    amount = FloatPrompt.ask("Amount", default=0)
    if amount <= 0:
        console.print("[red]Amount must be positive.[/red]")
        return
    category = Prompt.ask("Category", default="Other").strip()
    desc = Prompt.ask("Description", default="")
    d = Prompt.ask("Date", default=date.today().isoformat())
    execute("INSERT INTO expenses(amount,category,description,expense_date) VALUES(?,?,?,?)",
            (amount, category, desc, d))
    console.print("[green]✓ Expense added[/green]")

def set_budget():
    month = Prompt.ask("Month (YYYY-MM)", default=date.today().strftime("%Y-%m"))
    amount = FloatPrompt.ask("Monthly budget")
    execute("""INSERT INTO budgets(month,amount) VALUES(?,?)
               ON CONFLICT(month) DO UPDATE SET amount=excluded.amount""",
            (month, amount))
    console.print("[green]✓ Budget saved[/green]")

def view_expenses():
    rows = query_all("SELECT * FROM expenses ORDER BY expense_date DESC,id DESC")
    t = Table(title="Expenses")
    for c in ["ID","Amount","Category","Description","Date"]:
        t.add_column(c)
    for r in rows:
        t.add_row(str(r["id"]), f"₹{r['amount']:.2f}", r["category"],
                  r["description"] or "-", r["expense_date"])
    console.print(t)

def summary():
    month = date.today().strftime("%Y-%m")
    total = query_one("SELECT COALESCE(SUM(amount),0) total FROM expenses WHERE substr(expense_date,1,7)=?",
                      (month,))["total"]
    budget = query_one("SELECT amount FROM budgets WHERE month=?", (month,))
    bycat = query_all("""SELECT category,SUM(amount) total FROM expenses
                         WHERE substr(expense_date,1,7)=?
                         GROUP BY category ORDER BY total DESC""", (month,))
    console.print(Panel(
        f"[bold]Month:[/bold] {month}\n"
        f"[bold]Spent:[/bold] ₹{total:.2f}\n"
        f"[bold]Budget:[/bold] ₹{budget['amount']:.2f}" if budget else
        f"[bold]Month:[/bold] {month}\n[bold]Spent:[/bold] ₹{total:.2f}\n[bold]Budget:[/bold] Not set",
        title="💰 Monthly Summary"
    ))
    if budget and total >= budget["amount"] * .8:
        console.print("[yellow]⚠ You have used 80%+ of your budget.[/yellow]")
    t = Table(title="Category Analysis")
    t.add_column("Category"); t.add_column("Amount")
    for r in bycat:
        t.add_row(r["category"], f"₹{r['total']:.2f}")
    console.print(t)

def expense_menu():
    while True:
        clear()
        title("💰 EXPENSE TRACKER", "SPEND SMART • STAY ON BUDGET", APP_GREEN)
        month = date.today().strftime("%Y-%m")
        spent = query_one("SELECT COALESCE(SUM(amount),0) total FROM expenses WHERE substr(expense_date,1,7)=?", (month,))["total"]
        row = query_one("SELECT amount FROM budgets WHERE month=?", (month,))
        budget = row["amount"] if row else 0
        remaining = budget - spent if budget else 0
        console.print(Columns([
            stat_card("SPENT", f"₹{spent:.0f}", "This month", APP_GREEN),
            stat_card("BUDGET", f"₹{budget:.0f}" if budget else "—", "Monthly limit", APP_YELLOW),
            stat_card("REMAINING", f"₹{remaining:.0f}" if budget else "—", "Available", APP_GREEN if remaining >= 0 else APP_RED),
        ], equal=True, expand=True))
        choices = {"1":"➕  Add Expense","2":"📋  View Expenses","3":"📊  Monthly Summary","4":"🎯  Set Monthly Budget","0":"↩  Back"}
        menu(choices, APP_GREEN)
        footer("Choose a finance action")
        c = Prompt.ask("", choices=list(choices), default="0", show_default=False)
        if c=="1": add_expense()
        elif c=="2": view_expenses()
        elif c=="3": summary()
        elif c=="4": set_budget()
        else: break
        Prompt.ask("\nPress Enter", default="")
