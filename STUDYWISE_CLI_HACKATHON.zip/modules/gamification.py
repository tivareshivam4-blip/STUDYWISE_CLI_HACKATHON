from datetime import date, timedelta
from database.db import query_one, execute

def get_level(xp):
    # Level n requires n*100 cumulative XP using a simple 100 XP level curve.
    level = xp // 100 + 1
    current = xp % 100
    return level, current, 100

def add_xp(amount):
    row = query_one("SELECT xp, streak, last_active FROM profile WHERE id=1")
    today = date.today()
    streak = row["streak"]
    last = row["last_active"]

    if last != today.isoformat():
        if last:
            d = date.fromisoformat(last)
            if d == today - timedelta(days=1):
                streak += 1
            elif d != today:
                streak = 1
        else:
            streak = 1
        execute("UPDATE profile SET xp=xp+?, streak=?, last_active=? WHERE id=1",
                (amount, streak, today.isoformat()))
    else:
        execute("UPDATE profile SET xp=xp+? WHERE id=1", (amount,))

def mark_activity():
    add_xp(0)
