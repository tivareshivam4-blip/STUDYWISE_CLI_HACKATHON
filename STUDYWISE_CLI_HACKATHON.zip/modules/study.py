import time
from datetime import date, datetime
from rich.console import Console
from rich.table import Table
from rich.prompt import Prompt, IntPrompt
from rich.panel import Panel
from rich.columns import Columns
from ui import clear, title, menu, footer, stat_card, APP_CYAN, APP_GREEN

from database.db import execute, query_all, query_one
from modules.gamification import add_xp

console = Console()

def add_subject():
    name = Prompt.ask("Subject name").strip()
    if not name:
        return
    try:
        execute("INSERT INTO subjects(name, created_at) VALUES(?,?)",
                (name, datetime.now().isoformat(timespec="seconds")))
        console.print("[green]✓ Subject added[/green]")
    except Exception:
        console.print("[yellow]Subject already exists.[/yellow]")

def list_subjects():
    rows = query_all("SELECT * FROM subjects ORDER BY name")
    if not rows:
        console.print("[yellow]No subjects yet.[/yellow]")
        return []
    t = Table(title="Subjects")
    t.add_column("ID"); t.add_column("Subject")
    for r in rows:
        t.add_row(str(r["id"]), r["name"])
    console.print(t)
    return rows

def add_task():
    if not list_subjects():
        return
    sid = IntPrompt.ask("Subject ID")
    title = Prompt.ask("Task/topic")
    task_date = Prompt.ask("Date", default=date.today().isoformat())
    duration = IntPrompt.ask("Duration (minutes)", default=60)
    if query_one("SELECT id FROM subjects WHERE id=?", (sid,)) is None:
        console.print("[red]Invalid subject.[/red]")
        return
    execute("""INSERT INTO study_tasks(subject_id,title,task_date,duration,status,created_at)
               VALUES(?,?,?,?,?,?)""",
            (sid, title, task_date, duration, "pending",
             datetime.now().isoformat(timespec="seconds")))
    console.print("[green]✓ Study task created[/green]")

def view_tasks():
    rows = query_all("""SELECT t.id,s.name,t.title,t.task_date,t.duration,t.status
                        FROM study_tasks t JOIN subjects s ON s.id=t.subject_id
                        ORDER BY t.task_date,t.id""")
    t = Table(title="Study Plan")
    for c in ["ID","Subject","Topic","Date","Min","Status"]:
        t.add_column(c)
    for r in rows:
        t.add_row(str(r["id"]), r["name"], r["title"], r["task_date"],
                  str(r["duration"]), r["status"])
    console.print(t)

def complete_task():
    view_tasks()
    tid = IntPrompt.ask("Task ID to complete")
    row = query_one("SELECT status FROM study_tasks WHERE id=?", (tid,))
    if not row:
        console.print("[red]Task not found.[/red]")
        return
    if row["status"] == "completed":
        console.print("[yellow]Already completed.[/yellow]")
        return
    execute("UPDATE study_tasks SET status='completed' WHERE id=?", (tid,))
    add_xp(20)
    console.print("[green]✓ Task completed! +20 XP[/green]")

def start_timer():
    view_tasks()
    tid = IntPrompt.ask("Task ID")
    task = query_one("SELECT * FROM study_tasks WHERE id=?", (tid,))
    if not task:
        console.print("[red]Task not found.[/red]")
        return
    console.print(Panel(f"[bold]{task['title']}[/bold]\n{task['duration']} minutes",
                        title="Study Session"))
    mins = IntPrompt.ask("Minutes to run", default=min(task["duration"], 25))
    console.print("[cyan]Timer started. Press Ctrl+C to stop.[/cyan]")
    try:
        for remaining in range(mins * 60, 0, -1):
            print(f"\rTime remaining: {remaining//60:02d}:{remaining%60:02d}", end="", flush=True)
            time.sleep(1)
        print()
        console.print("[green]✓ Session complete![/green]")
    except KeyboardInterrupt:
        print()
        console.print("[yellow]Timer stopped early.[/yellow]")
    execute("""INSERT INTO study_sessions(subject_id,task_id,minutes,session_date)
               VALUES(?,?,?,?)""",
            (task["subject_id"], tid, mins, date.today().isoformat()))
    add_xp(20)
    console.print("[green]+20 XP[/green]")

def study_menu():
    while True:
        clear()
        title("📚 STUDY PLANNER", "PLAN • FOCUS • COMPLETE", APP_CYAN)
        today = date.today().isoformat()
        pending = query_one("SELECT COUNT(*) c FROM study_tasks WHERE task_date=? AND status='pending'", (today,))["c"]
        done = query_one("SELECT COUNT(*) c FROM study_tasks WHERE task_date=? AND status='completed'", (today,))["c"]
        minutes = query_one("SELECT COALESCE(SUM(minutes),0) m FROM study_sessions WHERE session_date=?", (today,))["m"]
        console.print(Columns([
            stat_card("PENDING", str(pending), "Today's tasks", APP_CYAN),
            stat_card("COMPLETED", str(done), "Today's tasks", APP_GREEN),
            stat_card("FOCUS TIME", f"{minutes} min", "Logged today", APP_CYAN),
        ], equal=True, expand=True))
        choices = {
            "1":"➕  Add Subject", "2":"📝  Add Study Task", "3":"📅  View Study Plan",
            "4":"✓   Complete Task", "5":"⏱   Start Study Timer", "0":"↩   Back"
        }
        menu(choices, APP_CYAN)
        footer("Choose a study action")
        c = Prompt.ask("", choices=list(choices), default="0", show_default=False)
        if c=="1": add_subject()
        elif c=="2": add_task()
        elif c=="3": view_tasks()
        elif c=="4": complete_task()
        elif c=="5": start_timer()
        else: break
        Prompt.ask("\nPress Enter", default="")
