from database.db import init_db, execute, query_one
from modules.gamification import get_level

def test_level():
    assert get_level(0) == (1,0,100)
    assert get_level(250)[0] == 3

def test_database():
    init_db()
    sid = execute("INSERT OR IGNORE INTO subjects(name,created_at) VALUES('TEST','now')")
    assert query_one("SELECT name FROM subjects WHERE name='TEST'")["name"] == "TEST"
